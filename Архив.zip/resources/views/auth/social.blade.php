<div class="text-center pt-4 pb-3">
    <h6 class="overline-title overline-title-sap"><span>{{ __('or') }}</span></h6>
</div>
<ul class="nav justify-center gx-8">
    <li class="nav-item"><a class="nav-link" href="{{ route('social.google.auth') }}">Google</a></li>
    <li class="nav-item"><a class="nav-link" href="{{ route('social.vkontakte.auth') }}">Vkontakte</a></li>
</ul>