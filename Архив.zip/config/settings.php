<?php

return [
    'currency_icon' => 'coins'
];
