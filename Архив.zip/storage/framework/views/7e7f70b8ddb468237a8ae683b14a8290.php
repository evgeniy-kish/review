<?php

/**
 * @var Article $article
 */

use App\Models\Article;

?>


<?php $__env->startSection('title'); ?>Добавить статью в блог<?php $__env->stopSection(); ?>
<?php $__env->startSection('description'); ?>Добавить статью в блог<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.blog.articles.form', compact('article'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/panel/blog/articles/create.blade.php ENDPATH**/ ?>