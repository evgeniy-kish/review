<!doctype html>
<html lang="ru" class="js">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('description', 'Панель управления'); ?>">

    <!-- <link rel="apple-touch-icon" sizes="180x180" href="/images/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/images/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/images/favicons/favicon-16x16.png">
    -->

    <link rel="icon" type="image/svg+xml" href="/img/core-img/logo.svg">
    <link rel="stylesheet" href="/dashboard/css/app.css?v=2">
    <?php echo $__env->yieldPushContent('style'); ?>
    <title><?php echo $__env->yieldContent('title', 'Отзовик'); ?></title>
</head>
<body class="nk-body bg-lighter npc-general has-sidebar">
<div class="nk-app-root">
    <div class="nk-main">

        <?php echo $__env->make('panel.blocks.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="nk-wrap ">
            <div class="nk-header nk-header-fixed is-light">
                <div class="container-fluid">
                    <div class="nk-header-wrap">
                        <div class="nk-menu-trigger d-xl-none ml-n1">
                            <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                        </div>
                        <div class="nk-header-brand d-xl-none">
                            <a href="<?php echo e(route('panel.index')); ?>" class="logo-link">
                                <img class="logo-light logo-img" src="/dashboard/images/logo.png" srcset="/dashboard/images/logo2x.png 2x" alt="logo">
                                <img class="logo-dark logo-img" src="/dashboard/images/logo-dark.png" srcset="/dashboard/images/logo-dark2x.png 2x" alt="logo-dark">
                            </a>
                        </div>
                        <?php echo $__env->make('panel.blocks.news', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('panel.blocks.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>

            <div class="nk-content ">
                <div class="container-fluid">
                    <div class="nk-content-inner">
                        <div class="nk-content-body">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="nk-footer">
                <div class="container-fluid">
                    <div class="nk-footer-wrap">
                        <div class="nk-footer-copyright"> &copy; <?php echo e(date('Y')); ?> <a href="" target="_blank"><?php echo e(config('app.name', 'Отзовик')); ?></a>
                        </div>
                        <div class="nk-footer-links">
                            <ul class="nav nav-sm">
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('terms-for-use')); ?>">Пользовательское соглашение</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('privacy-policy')); ?>">Политика конфиденциальности</a></li>
                                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('support')); ?>">Поддержка</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->yieldContent('modal'); ?>
<script src="/dashboard/js/bundle.js"></script>
<script src="/dashboard/js/scripts.js"></script>
<?php if(session('flash')): ?>
    <script>
      Swal.fire(
        "<?php echo e(session('flash.title', '👌')); ?>",
        "<?php echo e(session('flash.message', 'Yea!')); ?>",
        "<?php echo e(session('flash.type', 'success')); ?>",
      );
    </script>
<?php endif; ?>
<?php if(session('error')): ?>
    <script>
      Swal.fire(
        "<?php echo e(session('error.title', '⛔')); ?>",
        "<?php echo e(session('error.message', 'Ouch!')); ?>",
        "<?php echo e(session('error.type', 'error')); ?>",
      );
    </script>
<?php endif; ?>
<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/layouts/panel.blade.php ENDPATH**/ ?>