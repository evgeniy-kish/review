<?php
/**
 * @var \App\Models\Category[] $categories
 */
?>


<?php $__env->startSection('title', 'Все отзывы о компаниях, услугах, товарах и фильмах | iRate'); ?>
<?php $__env->startSection('description', 'Читайте свежие отзывы реальных людей на портале iRate. Оставьте отзыв о личном опыте.'); ?>

<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Area-->
<div class="breadcrumb--area bg-img bg-overlay--gray jarallax" style="background-image: url('/img/custom-img/categories.jpg');">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <div class="breadcrumb-content">
                    <h2 class="breadcrumb-title"><?php echo e(__('Reviews')); ?></h2>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center">
                            <li class="breadcrumb-item"><a href="/"><?php echo e(__('Home')); ?></a></li>
                            <li class="breadcrumb-item active"><a href="#"><?php echo e(__('All categories')); ?></a></li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Reviews Area-->
<section class="reviews-area section-padding-120">
    <div class="container">
        <ul id="nav_accordion" class="nav flex-column">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="accordion-item">
                <a class="accordion-button collapsed"
                    data-toggle="collapse"
                    data-target="#menu-item-<?php echo e($category->id); ?>"
                    href="#"><?php echo e($category->title); ?><i class="bi small bi-caret-down-fill"></i>
                </a>
                <ul id="menu-item-<?php echo e($category->id); ?>" class="submenu collapse">
                    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="position-relative">
                        <a class="nav-link" href="<?php echo e(route('reviews.product', ['category1' => $category->slug, 'category2' => $child->slug])); ?>">
                            <?php echo e($child->title); ?>

                            <?php if($child->products_count): ?>
                                <span class="position-absolute top-50 end-0 translate-middle badge rounded-pill bg-warning text-dark">
                                <?php echo e(($child->products_count > 99) ? '99+' : $child->products_count); ?>

                            </span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</section>

<!-- Features Area-->
<?php echo $__env->make('partials.features', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['h' => 'header2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Мой Mac/programm/irate/resources/views/categories/index.blade.php ENDPATH**/ ?>