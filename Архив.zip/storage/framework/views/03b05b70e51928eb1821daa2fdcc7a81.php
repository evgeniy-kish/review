<?php $__env->startSection('title', __('Email confirmation')); ?>
<?php $__env->startSection('description', __('Email confirmation')); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-block nk-block-middle nk-auth-body">
        <div class="brand-logo pb-5">
            <a href="<?php echo e(route('home')); ?>" class="logo-link">
                <img class="logo-light logo-img logo-img-lg" src="/img/core-img/logo-white.png" alt="logo">
                <img class="logo-dark logo-img logo-img-lg" src="/img/core-img/logo.png" alt="logo-dark">
            </a>
        </div>
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h5 class="nk-block-title"><?php echo e(__('Email confirmation')); ?></h5>
                <div class="nk-block-des">
                    <p><?php echo e(__('Thank you for registering!')); ?>

                        <br>
                        <?php echo e(__('To access all the features of the service, follow the link in the letter and confirm your email address.')); ?></p>
                </div>
                <?php if(session('status') === 'verification-link-sent'): ?>
                    <div class="alert alert-success alert-icon mt-2">
                        <em class="icon ni ni-check-circle"></em>
                        <?php echo e(__('To')); ?> <strong><?php echo e(auth()->user()->email); ?></strong>
                        <?php echo e(__('confirmation link sent.')); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <form action="<?php echo e(route('verification.send')); ?>" class="form-validate is-alter" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <button type="submit" class="btn btn-lg btn-primary btn-block"><?php echo e(__('Resend?')); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/irate.info/data/www/irate.info/resources/views/auth/verify-email.blade.php ENDPATH**/ ?>