<?php

/**
 * @var User $user
 */

use App\Models\User;

?>


<?php $__env->startSection('title', __('User profile')); ?>
<?php $__env->startSection('description', __('User profile')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area-->
    <div class="breadcrumb--area bg-img bg-overlay--gray jarallax" style="background-image: url('/img/custom-img/faq.jpg');">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2 class="breadcrumb-title"><?php echo e(__('User profile')); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="/"><?php echo e(__('Home')); ?></a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('users.show', $user)); ?>"><?php echo e(__('User profile')); ?> <?php echo e($user->name); ?></a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container py-5">
        <div class="row">
            <div class="col-lg-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <img src="<?php echo e($user->avatar); ?>" alt="avatar"
                                class="rounded img-fluid" style="width: 250px;">
                        <h5 class="my-3"><?php echo e($user->name); ?></h5>






                    </div>
                </div>


























            </div>
            <div class="col-lg-8">
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0"><?php echo e(__('Name')); ?></p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($user->name); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0"><?php echo e(__('Role')); ?></p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($user->roleName()); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-sm-3">
                                <p class="mb-0"><?php echo e(__('Registered')); ?></p>
                            </div>
                            <div class="col-sm-9">
                                <p class="text-muted mb-0"><?php echo e($user->created_at->format('d.m.Y')); ?> | <?php echo e($user->created_at->diffForHumans()); ?></p>
                            </div>
                        </div>
                        <hr>
                        <?php if($reviews = $user->reviews()->count()): ?>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0"><?php echo e(__('Total reviews')); ?></p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0"><?php echo e($reviews); ?></p>
                                </div>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php if($comments = $user->comments()->count()): ?>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0"><?php echo e(__('Total comments')); ?></p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0"><?php echo e($comments); ?></p>
                                </div>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php if($products = $user->products()->count()): ?>
                            <div class="row">
                                <div class="col-sm-3">
                                    <p class="mb-0"><?php echo e(__('Representation of')); ?></p>
                                </div>
                                <div class="col-sm-9">
                                    <p class="text-muted mb-0"><?php echo e($products); ?> <?php echo e(__('objects')); ?></p>
                                </div>
                            </div>
                            <hr>
                        <?php endif; ?>
                    </div>
                </div>




































































            </div>
        </div>
    </div>
    <div class="container">
        <div class="border-top">
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['h' => 'header2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/users/show.blade.php ENDPATH**/ ?>