<?php if(session('flash')): ?>
    <?php $__env->startPush('css'); ?>
        <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.min.css" rel="stylesheet">
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('script'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.3/dist/sweetalert2.all.min.js"></script>
        <script>
          Swal.fire(
            "<?php echo e(session('flash.title', '👌')); ?>",
            "<?php echo e(session('flash.message', 'Yea!')); ?>",
            "<?php echo e(session('flash.type', 'success')); ?>",
          );
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH /Volumes/Мой Mac/programm/irate/resources/views/partials/flash.blade.php ENDPATH**/ ?>