<?php

/**
 * @var Review $review
 */

use App\Models\Review;
?>



<?php $__env->startSection('title', __('Review of') . " {$review->product->title}"); ?>
<?php $__env->startSection('description', __('Review of') . " {$review->product->title}"); ?>

<?php $__env->startSection('content'); ?>
    <!-- Scroll Indicator-->
    <div id="scrollIndicator"></div>
    <!-- Breadcrumb Area-->
    <div class="breadcrumb--area bg-img bg-overlay jarallax" style="background-image: url(/img/custom-img/blog.jpg);">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('reviews.index')); ?>"><?php echo e(__('Reviews')); ?></a></li>
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('reviews.product', ['category1' => $review->product->category->parent->slug])); ?>">
                                        <?php echo e($review->product->category->parent->title); ?>

                                    </a>
                                </li>

                                <li class="breadcrumb-item" aria-current="page">
                                    <a href="<?php echo e(route('reviews.product', ['category1' => $review->product->category->parent->slug, 'category2' => $review->product->category->slug])); ?>">
                                        <?php echo e($review->product->category->title); ?>

                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a href="<?php echo e($review->product->getFullPath()); ?>">
                                        <?php echo e($review->product->title); ?>

                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- saasbox Blog Area-->
    <div class="saasbox--blog--area section-padding-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="post--like-post">
                    <?php if(auth()->guard()->check()): ?>
                        <a class="like-touch <?php echo e($review->is_liked ? 'liked': ''); ?>" href="#" data-action="<?php echo e(route('review.like', $review)); ?>">
                            <i class="fa fa-thumbs-o-up"></i>
                        </a>
                    <?php else: ?>
                        <a href="#"><i class="fa fa-thumbs-o-up"></i></a>
                    <?php endif; ?>
                    <span><?php echo e($review->likes_count ?: ''); ?></span>
                </div>
                <div class="col-12 col-sm-10 col-md-8">
                    <!-- Blog Details Area-->
                    <div class="single-blog-details-area">
                        <div class="card product-description-card mb-5">
                            <h6 class="product-meta-title mb-0 pl-5 py-4">
                                <a href="<?php echo e($review->product->getFullPath()); ?>">Отзыв о <?php echo e($review->product->title); ?></a>
                            </h6>
                            <div class="row g-0">
                                <div class="col-md-12 text-center p-4 mx-auto">
                                    <img src="<?php echo e($review->product->img); ?>" alt="<?php echo e($review->product->title); ?>" style="width: 300px; height: 300px">
                                    <ul class="ratings-list d-flex align-items-center justify-content-center mb-3">

                                        <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($review->product->rating >= $star): ?>
                                                <li><i class="lni-star-filled"></i></li>
                                            <?php else: ?>
                                                <li><i class="lni-star-empty"></i></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>

                                    <span>
                                        <?php if($review->product->reviews_count > 0): ?>
                                            <?php echo e(__('rating')); ?>: <?php echo e($review->product->rating); ?> <?php echo e(__('of')); ?> 5 (<?php echo e($review->product->reviews_count); ?> <?php echo e(trans_choice('dic.review', $review->product->reviews_count)); ?>)

                                        <?php else: ?>
                                            Пока нет отзывов
                                        <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="post-date mb-2"><?php echo e($review->created_at->format('d.m.Y H:i')); ?></div>
                        <!-- Данные продукта -->








                        <div class="">
                            <?php echo nl2br($review->body); ?>

                        </div>
                        <!-- Post Author-->
                        <div class="profile-content-wrapper">
                            <!-- Settings Option-->
                            <div class="profile-settings-option">
                                <a href="<?php echo e(route('users.show', $review->user_id)); ?>" data-toggle="tooltip" data-placement="left" title="<?php echo e(__('View profile')); ?>">
                                    <i class="lni lni-eye"></i>
                                </a>
                            </div>
                            <div class="container">
                                <!-- User Meta Data-->
                                <div class="user-meta-data d-flex align-items-center">
                                    <!-- User Thumbnail-->
                                    <div class="user-thumbnail">
                                        <img src="<?php echo e($review->user->avatar); ?>" alt="">
                                    </div>
                                    <!-- User Content-->
                                    <div class="user-content">
                                        <div class="d-flex justify-content-start">
                                            <h6><?php echo e($review->user->name); ?></h6>
                                            <!-- Share Button-->
                                            <div class="share-button ms-2">
                                                <a href="#"><i class="fa fa-facebook"></i></a>
                                                <a href="#"><i class="fa fa-twitter"></i></a>
                                                <a href="#"><i class="fa fa-pinterest"></i></a>
                                            </div>
                                        </div>
                                        <p><?php echo e($review->user->roleName()); ?></p>
                                        <div class="user-meta-data d-flex align-items-center justify-content-between">
                                            <p class="mx-1">
                                                <span><?php echo e(__('grade')); ?></span>
                                                <span class="rating">
                                                    <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($review->rating >= $star): ?>
                                                            <i class="lni lni-star-filled"></i>
                                                        <?php else: ?>
                                                            <i class="lni lni-star-empty"></i>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                            </p>
                                            <p class="mx-1">
                                                <span><?php echo e(trans_choice('dic.review', $review->user->reviews_count)); ?></span>
                                                <span class="counter"><?php echo e($review->user->reviews_count); ?></span>
                                            </p>
                                            <p class="mx-1"><span><?php echo e(__('rating')); ?></span><span class="counter"><?php echo e($review->user->reviews_count + $review->user->comments_count); ?></span></p>
                                            <p class="mx-1"><span><?php echo e(__('member')); ?></span><span class="counter"><?php echo e($review->user->created_at->diffForHumans('', true)); ?></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Post Tag & Share Button-->
                        <div class="post-tag-share-button d-sm-flex align-items-center justify-content-end my-5">
                            <!-- Post Tags-->







                        </div>
                    </div>
                    <!-- Comments Area -->
                    <?php echo $__env->make('partials.comments', ['comments' => $review->comments], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Comments Form -->
                    <?php echo $__env->make('partials.comment_form', ['route' => route('review.comment.store', $review)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Cool Facts Area-->
    <section class="cta-area cta3 py-5">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-sm-8">
                    <div class="cta-text mb-4 mb-sm-0">
                        <h3 class="text-white mb-0"><?php echo e(__('Interesting product')); ?></h3>
                    </div>
                </div>
                <div class="col-12 col-sm-4 text-sm-right"><a class="btn saasbox-btn white-btn" href="#"><?php echo e(__('Go')); ?></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script src="/js/app.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/irate.info/data/www/irate.info/resources/views/reviews/show.blade.php ENDPATH**/ ?>