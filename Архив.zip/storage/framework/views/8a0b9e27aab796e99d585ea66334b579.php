<div class="nk-block">
    <div class="card card-bordered card-stretch">
        <div class="card-inner-group">
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">Заголовок</span></div>
                        <div class="nk-tb-col tb-col-sm"><span class="sub-text"><em class="icon ni ni-list"></em></span></div>
                        <div class="nk-tb-col tb-col-sm"><span class="sub-text"><em class="icon ni ni-file-img"></em></span></div>
                        <div class="nk-tb-col"><span class="sub-text">Рейтинг</span></div>
                        <div class="nk-tb-col tb-col-mb"><span class="sub-text">Категория</span></div>
                        <div class="nk-tb-col tb-col-sm"><span class="sub-text">Отзывы</span></div>

                        <div class="nk-tb-col nk-tb-col-tools text-right">
                            <em class="icon ni ni-setting-alt"></em>
                        </div>
                    </div>

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="nk-tb-item">
                            <div class="nk-tb-col">
                                <a href="<?php echo e(route('panel.products.edit', $product)); ?>"><span class="fw-medium"><?php echo e($product->title); ?></span></a>
                            </div>
                            <div class="nk-tb-col tb-col-sm"><span><?php echo e($product->values_count); ?></span></div>
                            <div class="nk-tb-col tb-col-sm">
                                <a href="<?php echo e(route('panel.products.gallery.edit', $product)); ?>" data-toggle="tooltip" data-placement="top" title="Редактировать галерею"><?php echo e($product->photos_count); ?></a>
                            </div>
                            <div class="nk-tb-col">
                                <span class="fw-medium"><?php echo e($product->ratingFormat()); ?></span>
                            </div>
                            <div class="nk-tb-col tb-col-mb">
                                <a href="#"><?php echo e($product->category->title); ?></a>
                            </div>
                            <div class="nk-tb-col tb-col-sm"><span><?php echo e($product->reviews_count); ?></span></div>

                            <div class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-1">
                                    <?php if($product->trashed()): ?>
                                        <li class="nk-tb-action-hidden">
                                            <form action="<?php echo e(route('panel.products.restore', $product)); ?>" method="post">
                                                <button type="submit" class="btn btn-trigger btn-icon" data-toggle="tooltip" data-placement="top" title="Восстановить"><em class="icon ni ni-history"></em></button>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </li>
                                        <li>
                                            <div class="drodown">
                                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li>
                                                            <a href="#"><em class="icon ni ni-opt-dot-fill"></em><span>Настройки</span></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    <?php else: ?>
                                        <li class="nk-tb-action-hidden">
                                            <a href="<?php echo e(route('panel.products.edit', $product)); ?>" class="btn btn-trigger btn-icon" data-toggle="tooltip" data-placement="top" title="Редактировать"><em class="icon ni ni-edit-fill"></em></a>
                                        </li>
                                        <li class="nk-tb-action-hidden">
                                            <a href="<?php echo e(route('reviews.product', ['category1' => $product->category->parent->slug, 'category2' => $product->category->slug, 'product' => $product->slug])); ?>" class="btn btn-trigger btn-icon" data-toggle="tooltip" data-placement="top" title="Посмотреть на сайте" target="_blank"><em class="icon ni ni-eye-fill"></em></a>
                                        </li>
                                        <li class="nk-tb-action-hidden">
                                            <form action="<?php echo e(route('panel.products.destroy', $product)); ?>" method="post" onsubmit="return confirm('Удалить продукт?')">
                                                <button type="submit" class="btn btn-trigger btn-icon" data-toggle="tooltip" data-placement="top" title="Удалить"><em class="icon ni ni-trash-fill"></em></button>
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </li>
                                        <li>
                                            <div class="drodown">
                                                <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
                                                <div class="dropdown-menu dropdown-menu-right">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li>
                                                            <a href="#"><em class="icon ni ni-opt-dot-fill"></em><span>Настройки</span></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/panel/products/table.blade.php ENDPATH**/ ?>