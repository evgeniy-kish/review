<?php if($products->count()): ?>
<div class="saasbox-tab-area section-padding-120">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-9 col-lg-6">
                <div class="section-heading text-center"><i class="lni-crown"></i>
                    <h2><?php echo e(__('Actual now')); ?></h2>
                    <h3><?php echo e(__('Find interesting places nearby')); ?></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="tab--area">
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item"><a class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>" id="tab--<?php echo e($loop->index + 1); ?>" data-toggle="tab" href="#tab<?php echo e($loop->index + 1); ?>" role="tab" aria-controls="tab<?php echo e($loop->index + 1); ?>" aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>"><?php echo e($product->category->title); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <div class="tab-content" id="myTabContent">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Tab Pane-->
                        <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>" id="tab<?php echo e($loop->index + 1); ?>" role="tabpanel" aria-labelledby="tab--<?php echo e($loop->index + 1); ?>">
                            <div class="row justify-content-between align-items-center">
                                <div class="col-12 col-md-6 col-xxl-5">
                                    <div class="tab--text mt-5">
                                        <h6><?php echo e($product->category->title); ?></h6>
                                        <h2><a href="<?php echo e(route('reviews.product', ['category1' => $product->category->parent->slug, 'category2' => $product->category->slug, 'product' => $product->slug])); ?>"><?php echo e($product->title); ?></a></h2>
                                        <?php echo Str::limit($product->body, 200); ?>

                                        <span class="d-block mt-4 mb-1"><?php echo e(__('Satisfied clients')); ?>: <?php echo e($product->rating / 5 * 100 . '%'); ?></span>
                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" style="width: <?php echo e($product->rating / 5 * 100 . '%'); ?>;" aria-valuenow="<?php echo e($product->rating / 5 * 100); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="tab-thumb mt-5"><img class="img-fluid" style="height: 30vh; width: 100%; object-fit: contain;" src="<?php echo e($product->img); ?>" alt="<?php echo e($product->title); ?>"></div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/partials/features.blade.php ENDPATH**/ ?>