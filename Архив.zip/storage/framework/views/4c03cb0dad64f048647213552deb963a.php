<div class="nk-block">
    <div class="card card-bordered card-stretch">
        <div class="card-inner-group">
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">id</span></div>
                        <div class="nk-tb-col"><span class="sub-text"><?php echo e(__('Product')); ?></span></div>
                        <div class="nk-tb-col"><span class="sub-text"><?php echo e(__('Text')); ?></span></div>
                        <div class="nk-tb-col tb-col-md"><em class="tb-asterisk icon ni ni-star-round"></em></div>
                        <div class="nk-tb-col"><span class="sub-text"><?php echo e(__('Status')); ?></span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text"><?php echo e(__('Date')); ?></span></div>
                    </div>

                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="nk-tb-item" href="<?php echo e(route('review.show', $review)); ?>">
                            <div class="nk-tb-col">
                                <?php echo e($review->id); ?>

                            </div>
                            <div class="nk-tb-col">
                                <?php echo e($review->product->title); ?>

                            </div>
                            <div class="nk-tb-col">
                                <?php echo e(str($review->short_text)->limit(40)); ?>

                            </div>
                            <div class="nk-tb-col tb-col-md"><span><?php echo e($review->rating); ?></span></div>
                            <div class="nk-tb-col">
                                <?php echo e($review->statusText()); ?>

                            </div>
                            <div class="nk-tb-col tb-col-md"><span><?php echo e($review->created_at->format('d-m-Y H:i')); ?></span></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /var/www/irate.info/data/www/irate.info/resources/views/cabinet/reviews/table.blade.php ENDPATH**/ ?>