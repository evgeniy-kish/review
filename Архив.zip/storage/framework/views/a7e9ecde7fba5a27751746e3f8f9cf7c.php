<div class="row g-5">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-12">
            <div class="card blog-card border-0 no-boxshadow rounded-0">
                <a class="d-block mb-4" href="<?php echo e(route('blog.show', ['rubric_slug' => $article->rubric->slug, 'article' => $article->slug])); ?>">
                    <img src="<?php echo e($article->img); ?>" alt="<?php echo e($article->title); ?>">
                </a>
                <div class="post-content">
                    <a class="d-block mb-1" href="<?php echo e(route('blog.rubric', $article->rubric)); ?>"><?php echo e($article->rubric->title); ?></a>
                    <a class="post-title d-block mb-3" href="<?php echo e(route('blog.show', ['rubric_slug' => $article->rubric->slug, 'article' => $article->slug])); ?>">
                        <h4><?php echo e($article->title); ?></h4>
                    </a>
                    <p><?php echo e($article->description); ?></p>
                    <div class="post-meta"><span class="text-muted"><?php echo e(__('Time to read')); ?> <?php echo e(time_to_read($article->body)); ?> <?php echo e(__('min.')); ?></span></div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/blog/rows.blade.php ENDPATH**/ ?>