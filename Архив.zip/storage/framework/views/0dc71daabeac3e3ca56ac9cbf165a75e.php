<?php
/**
 * @var Product $product
 */

use App\Models\Product;
?>


<?php $__env->startSection('title', $product->seo_title); ?>
<?php $__env->startSection('description', $product->seo_description); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="/assets/trum/trumbowyg.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area-->
    <div class="breadcrumb--area bg-img bg-overlay--gray jarallax" style="background-image: url('/img/custom-img/single.jpg');">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2 class="breadcrumb-title"><?php echo e($product->title); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                                <li class="breadcrumb-item"><a href="<?php echo e(route('reviews.index')); ?>"><?php echo e(__('Reviews')); ?></a></li>
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('reviews.product', ['category1' => $product->category->parent->slug])); ?>">
                                        <?php echo e($product->category->parent->title); ?>

                                    </a>
                                </li>
                                <li class="breadcrumb-item" aria-current="page">
                                    <a href="<?php echo e(route('reviews.product', ['category1' => $product->category->parent->slug, 'category2' => $product->category->slug])); ?>">
                                        <?php echo e($product->category->title); ?>

                                    </a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Product Details Area-->
    <div class="product-details-area product-details-page section-padding-120">
        <div class="container">
            <div class="card product-description-card mb-5">
                <h6 class="product-meta-title mb-0 pl-5 py-4"><?php echo e($product->title); ?></h6>
                <div class="row g-0">
                    <div class="col-md-4 text-center p-4">
                        <img src="<?php echo e($product->img); ?>" alt="<?php echo e($product->title); ?>" style="width: 300px; height: 300px">
                        <ul class="ratings-list d-flex align-items-center justify-content-center mb-3">
                            <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($product->rating >= $star): ?>
                                    <li><i class="lni-star-filled"></i></li>
                                <?php else: ?>
                                    <li><i class="lni-star-empty"></i></li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <span>
                            <?php if($product->reviews_count > 0): ?>
                                <?php echo e(__('rating')); ?>: <?php echo e($product->getRate()); ?> <?php echo e(__('of')); ?> 5 (<?php echo e($product->reviews_count); ?> <?php echo e(trans_choice('dic.review', $product->reviews_count)); ?>)
                            <?php else: ?>
                                Пока нет отзывов
                            <?php endif; ?>
                        </span>
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            
                            <?php echo $product->body; ?>

                            
                        </div>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">

                <!-- Product Review-->
                <!--          <div class="col-12 col-md-9 col-lg-12 mb-5">-->
                <!--            <div class="card product-review-card">-->
                <!--              <h6 class="product-meta-title mb-0 pl-5 py-4">ЗАО "Большая кормушка"</h6>-->
                <!--              <div class="card-body p-5 text-center">-->

                <!--              </div>-->
                <!--            </div>-->
                <!--          </div>-->
                <?php if($has_photo = $product->photos->isNotEmpty()): ?>
                    <div class="col-12 col-md-9 col-lg-6">
                        <!-- Product Image Wrapper-->
                        <div class="product-image-wrapper mb-5">

                            <img class="w-100" src="<?php echo e($product->photos[0]->path); ?>" alt="">
                            <!-- Related Image Carousel-->
                            <div class="related-image-carousel owl-carousel">
                                <?php $__currentLoopData = $product->photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <!-- Single Slide-->
                                    <a class="image-popup" href="<?php echo e($photo->path); ?>" data-effect="mfp-zoom-in">
                                        <img src="<?php echo e($photo->path); ?>" alt="">
                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <!-- Product Description-->
                <div class="col-12 col-md-9 <?php echo e($has_photo ? 'col-lg-6' : 'col-lg-12'); ?>">
                    <div class="card product-description-card mb-5">
                        <h6 class="product-meta-title mb-0 pl-5 py-4"><?php echo e(__('Information')); ?></h6>
                        <div class="card-body p-3 p-sm-4">
                            <!--                <h4 class="mb-3">Bonsai Tree with Superb Pot</h4>-->
                            <!--                <h3 class="product-price mb-4">$19.99<span>$32.89</span></h3>-->
                            <!--                <h6 class="mb-4">36 Product Left                            </h6>-->
                            <!--                <p>It's crafted with the latest trend of design & coded with all modern approaches. It's a robust & multi-dimensional usable template. It's crafted with the latest trend of design & coded with all modern approaches. It's a robust & multi-dimensional usable template. It's crafted with the latest trend of design & coded with all modern approaches.</p>-->
                            <!--                <form class="d-flex align-items-end mt-4" action="#">-->
                            <!--                  <div class="form-group mb-0">-->
                            <!--                    <label class="mr-2 mb-2" for="totalQuantity">Quantity</label>-->
                            <!--                    <input class="form-control" id="totalQuantity" min="1" max="12" name="quantity" value="1">-->
                            <!--                  </div>-->
                            <!--                  <button class="btn saasbox-btn ml-3" type="submit">Buy Now</button>-->
                            <!--                </form>-->
                            <div class="table-responsive">
                                <table class="table mb-4">
                                    <tbody>
                                    <?php $__currentLoopData = $product->category->allAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-3"><?php echo e($attribute->name); ?>:</td>
                                            <td class="px-3">
                                                <?php if($attribute->isLink()): ?>
                                                    <a href="<?php echo e($link = ($product->getValue($attribute->id) ?: '/')); ?>"><?= punycode_decode($link) ?: $link; ?></a>
                                                <?php else: ?>
                                                    <?php echo e($product->getValue($attribute->id) ?: '—'); ?>

                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Reviews Area-->
                <?php if($product->reviews_count > 0): ?>
                    <!-- Rating & Review Wrapper-->
                    <div class="rating-and-review-wrapper bg-white py-3 mb-3">
                            <div class="container">
                                <h6><?php echo e(__('Reviews')); ?></h6>
                                <div class="rating-review-content">
                                    <ul class="ps-0">
                                        <?php $__currentLoopData = $product->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="single-user-review d-flex">
                                                <div class="user-thumbnail"><img src="<?php echo e($review->user->avatar); ?>" alt=""></div>
                                                <a href="<?php echo e(route('review.show', $review)); ?>" class="rating-comment">
                                                    <div class="rating">
                                                        <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $star): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($review->rating >= $star): ?>
                                                                <i class="lni lni-star-filled"></i>
                                                            <?php else: ?>
                                                                <i class="lni lni-star-empty"></i>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                    <p class="mb-0"><?php echo e($review->user->name); ?></p>
                                                    <p class="comment mb-0"><?php echo e($review->short_text); ?></p>
                                                    <span class="name-date"><?php echo e($review->created_at->format('d.m.Y')); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>

                <!-- Ratings Submit Form-->
                <div class="ratings-submit-form bg-white py-3">
                    <div class="container">
                        <?php if(auth()->check() && auth()->user()->hasVerifiedEmail()): ?>
                            <h6><?php echo e(__('Leave review')); ?></h6>
                            <form id="reviews" action="<?php echo e(route('reviews.review.store', $product)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div  class="stars mb-3">
                                    <?php $__currentLoopData = range(1,5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input class="star-<?php echo e($item); ?>" type="radio" name="rating" value="<?php echo e($item); ?>" id="star<?php echo e($item); ?>">
                                        <label class="star-<?php echo e($item); ?>" for="star<?php echo e($item); ?>"></label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <span></span>
                                </div>
                                <!--suppress HtmlFormInputWithoutLabel -->
                                <textarea class="form-control" id="body" name="body" cols="30" rows="10" data-max-length="200" placeholder=" <?php echo e(__('Your message')); ?>" required></textarea>
                                <div class="mt-3">
                                    <button class="btn btn-primary" type="submit"><?php echo e(__('Send')); ?></button>
                                </div>
                            </form>
                        <?php else: ?>
                            <p class="alert alert-warning">
                                <?php echo e(__('To leave a review you need')); ?>

                                <?php if(!auth()->check()): ?>
                                    <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                    <?php echo e(__('or')); ?>

                                    <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                <?php else: ?>
                                    <?php echo e(__('confirm your email')); ?>

                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Cool Facts Area-->
    <section class="cta-area cta3 py-5">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-sm-8">
                    <div class="cta-text mb-4 mb-sm-0">
                        <h3 class="text-white mb-0"><?php echo e(__('Interesting product')); ?></h3>
                    </div>
                </div>
                <div class="col-12 col-sm-4 text-sm-right"><a class="btn saasbox-btn white-btn" href="#"><?php echo e(__('Go')); ?></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php if(auth()->guard()->check()): ?>
    <?php echo $__env->make('partials.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('script'); ?>
        <script src="/assets/trum/trumbowyg.min.js"></script>
        <script>
      (function ($) {
        $('#reviews').on('submit', function (e) {
          e.preventDefault();
          const f = $(this);
          const b = f.find('button');

          b.attr('disabled', 'disabled');

          $.post(f.attr('action'), f.serialize(), null, 'json')
            .done(function (j) {

              if('response' in j && 'activity' in j) {

                if(1 === j['activity']) {
                    return window.location.reload();
                }

                f.html('Отзыв успешно отправлен на модерацию');

              }
            })
            .fail(function (e) {
              if (e.status !== 422 || !('errors' in e['responseJSON'])) {
                return alert('Forbidden!');
              }

              const er = [];

              for (let o in e['responseJSON']['errors']) {
                er.push(e['responseJSON']['errors'][o][0]);
              }

              return alert(er.join('\n'));
            })
            .always(function () {
              b.removeAttr('disabled');
            });

        });
      })(jQuery);
    </script>
        <script>
  $(function () {
    $('#body').trumbowyg({
      lang: 'ru',
      svgPath: '/assets/trum/icons.svg',
      autogrow: true,
      btnsDef: {
        image: { dropdown: ['insertImage', 'upload'], ico: 'insertImage' },
        align: { dropdown: ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'], ico: 'justifyLeft' }
      },
      btns: [
        ['undo', 'redo'],
        ['formatting'],
        ['align'],
        ['strong', 'em', 'underline', 'del'],
        ['foreColor', 'backColor'],
        ['link'],
        ['image'],
        ['unorderedList', 'orderedList'],
        ['removeformat'],
        ['viewHTML'],
        ['fullscreen'],
      ],
      plugins: {
        upload: {
          serverPath: '/api/services/upload/trum',
          fileFieldName: 'file',
          urlPropertyName: 'link',
          data: [{ name: 'file', value: 1 }]
        }
      }
    });
  });
</script>
    <?php $__env->stopPush(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', ['h' => 'header2'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/products/show.blade.php ENDPATH**/ ?>