<?php

/**
 * @var Review[] $reviews
 */

use App\Models\Review;
?>
<div class="nk-block">
    <div class="card card-bordered card-stretch">
        <div class="card-inner-group">
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                <input type="checkbox" class="custom-control-input" id="<?php echo e(isset($moderation) ? 'rid_all_' . $moderation : 'rid_all'); ?>" <?php echo e(isset($moderation) ? 'disabled' : ''); ?>>
                                <label class="custom-control-label" for="<?php echo e(isset($moderation) ? 'rid_all_' . $moderation : 'rid_all'); ?>"></label>
                            </div>
                        </div>
                        <div class="nk-tb-col"><span class="sub-text">Продукт</span></div>
                        <div class="nk-tb-col"><span class="sub-text">Автор</span></div>
                        <div class="nk-tb-col"><span class="sub-text">Текст</span></div>
                        <div class="nk-tb-col tb-col-md"><em class="tb-asterisk icon ni ni-star-round"></em></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">Дата</span></div>
                    </div>

                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="nk-tb-item" href="<?php echo e(route('panel.reviews.edit', $review)); ?>">
                            <div class="nk-tb-col nk-tb-col-check">
                                <div class="custom-control custom-control-sm custom-checkbox notext">
                                    <input type="checkbox" class="custom-control-input" id="rid<?php echo e($review->id); ?>" name="<?php echo e(isset($moderation) ? 'rid_' . $moderation : 'rid'); ?>" value="<?php echo e($review->id); ?>" <?php echo e(isset($moderation) ? 'disabled' : ''); ?>>
                                    <label class="custom-control-label" for="rid<?php echo e($review->id); ?>"></label>
                                </div>
                            </div>
                            <div class="nk-tb-col">
                                <?php echo e($review->product->title); ?>

                            </div>
                            <div class="nk-tb-col">
                                <?php echo e($review->user->name); ?>

                            </div>
                            <div class="nk-tb-col">
                                <?php echo e(str($review->short_text)->limit(120)); ?>

                            </div>

                            <div class="nk-tb-col tb-col-md"><span><?php echo e($review->rating); ?></span></div>
                            <div class="nk-tb-col tb-col-md"><span><?php echo e($review->created_at->format('d-m-Y H:i')); ?></span></div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/irate.info/data/www/irate.info/resources/views/panel/reviews/table.blade.php ENDPATH**/ ?>