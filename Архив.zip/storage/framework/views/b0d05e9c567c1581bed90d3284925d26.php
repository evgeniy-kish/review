<?php

/**
 * @var Product $product
 */

use App\Models\Product;
?>


<?php $__env->startSection('title', "Редактировать: {$product->title}"); ?>
<?php $__env->startSection('description', "Редактировать: {$product->title}"); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="/dashboard/css/summernote.css">
    <!--suppress CssUnusedSymbol -->
    <style>
      .crutch-dropzone {
        min-height: 206px
      }

      .crutch-dropzone + .invalid {
        bottom: 160px !important;
        right: 50% !important;
        transform: translateX(50%);
      }

      .dz-message {
        display: flex;
        align-items: center;
      }

      .dz-message > div:first-child {
        margin-right: 10px;
      }

      .dz-message > div:first-child > img {
        object-fit: cover;
        border-radius: 20px;
      }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <nav>
        <ul class="breadcrumb breadcrumb-arrow">
            <li class="breadcrumb-item"><a href="<?php echo e(route('panel.products.index')); ?>">Продукты</a></li>
            <li class="breadcrumb-item active"><?php echo e($product->title); ?></li>
        </ul>
    </nav>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title d-flex align-items-end">Редактировать: <?php echo e($product->title); ?></h3>
            </div>
        </div>
        <?php if($product->trashed()): ?>
            <div class="alert alert-warning d-inline-block mt-2" role="alert">Внимание: Продукт в корзине</div>
        <?php endif; ?>
    </div>

    <p class="lead">
        <span>Галерея: <?php echo e($product->photos->count()); ?> фото</span>
        <span class="icon ni ni-chevrons-right"></span>
        <a href="<?php echo e(route('panel.products.gallery.edit', $product)); ?>">Редактировать</a>
    </p>

    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-md-8 col-lg-9">
                <div class="card card-bordered mb-4">
                    <div class="card-inner">
                        <form class="crutch-validate is-alter" action="<?php echo e(route('panel.products.update', $product)); ?>" method="post">
                            <div class="row g-gs">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="form-label" for="title">Название продукта (организации)</label>
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control" id="title" name="title" value="<?php echo e($product->title); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="form-label" for="category_id">Категория</label>
                                        <div class="form-control-wrap">
                                            <select id="category_id" class="form-control form-select select2-hidden-accessible" name="category_id" data-placeholder="Выбрать" data-search="on" data-msg="Выберите Категорию" required>
                                                <option label="empty" value=""></option>

                                                <?php $__currentLoopData = \App\Models\Category::getTreeCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <optgroup label="<?php echo e($category['title']); ?>">
                                                        <?php $__currentLoopData = $category['children'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($child['id']); ?>" <?php echo e((int)$child['id'] === $product->category_id ? 'selected' : ''); ?>>
                                                                <?php echo e($child['title']); ?>

                                                            </option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </optgroup>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label class="form-label" for="reviews_mod">Премодерация отзывов</label>
                                        <div class="form-control-wrap">
                                            <select id="reviews_mod" class="form-control form-select select2-hidden-accessible" name="reviews_mod" data-placeholder="Выбрать" data-msg="Выберите Статус" required>
                                                <option label="empty" value=""></option>
                                                <?php $__currentLoopData = \App\Models\Product::reviewsModList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>" <?php if($product->reviews_mod === $key): echo 'selected'; endif; ?>><?php echo e($status); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-gs">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-label" for="slug">Slug</label>
                                        <div class="form-control-wrap">
                                            <div class="input-group">
                                                <input type="text" class="form-control" id="slug" name="slug" value="<?php echo e($product->slug); ?>" required>
                                                <div class="input-group-append">
                                                    <button id="slug-generate" class="btn btn-outline-primary" type="button">Сгенерировать</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label" for="description">SEO Описание</label>
                                        <div class="form-control-wrap">
                                            <textarea style="min-height: 120px" class="form-control form-control-sm" id="description" name="description" placeholder="Краткое описание"><?php echo e($product->description); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label class="form-label">Лого</label>
                                        <!--suppress HtmlFormInputWithoutLabel -->
                                        <input style="visibility:hidden" id="img" type="text" name="img" value="<?php echo e($product->img); ?>" required data-msg="Загрузите картинку">
                                        <div class="form-control crutch-dropzone dz-clickable">
                                            <div class="dz-message" data-dz-message>
                                                <div id="product-img">
                                                    <img src="<?php echo e($product->img ?: '/img/special/no-image-300x300.png'); ?>" width="150" height="150" alt="<?php echo e($product->title); ?>">
                                                </div>
                                                <div>
                                                    <span class="dz-message-text">Перетащите картинку сюда</span>
                                                    <span class="dz-message-or">или</span>
                                                    <button type="button" class="btn btn-primary">ВЫБРАТЬ</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row g-gs">
                                <div class="col-12">
                                    <div class="form-group">
                                        <label class="form-label" for="body">Контент</label>
                                        <div class="form-control-wrap">
                                            <textarea style="height: 400px" class="form-control form-control-sm summernote-basic" id="body" name="body" placeholder="Текст продукта" required><?php echo $product->body; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-lg btn-primary">Сохранить продукт</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row g-gs">
                    <div class="col-4">
                        <div class="card card-bordered h-100">
                            <div class="card-inner">
                                <form class="crutch-validate is-alter" action="<?php echo e(route('panel.products.user', $product)); ?>" method="post">
                                    <div class="form-group">
                                        <label class="form-label" for="user_id">ID user</label>
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control" id="user_id" name="user_id" value="<?php echo e($product->user_id); ?>">
                                            <?php if($product->user_id): ?>
                                                <span><?php echo e($product->user->name); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Сохранить</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card card-bordered h-100">
                            <div class="card-inner">
                                <form class="crutch-validate is-alter" action="<?php echo e(route('panel.products.premium', $product)); ?>" method="post">
                                    <div class="form-group">
                                        <label class="form-label" for="days">
                                            <?php if($product->premium_at): ?>
                                                <?php if($product->isPremium()): ?>
                                                    <span class="text-warning">
                                                        Действует ещё <?php echo e($days = $product->premium_at->diffInDays()); ?>

                                                        <?php echo e(trans_choice('dic.days', $days)); ?>

                                                        до <?php echo e($product->premium_at->format('d.m.Y H:i')); ?>

                                                    </span>
                                                <?php else: ?>
                                                   <span class="text-danger">Премиум закончился <?php echo e($product->premium_at->diffForHumans()); ?></span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span>Premium days</span>
                                            <?php endif; ?>
                                        </label>
                                        <div class="form-control-wrap">
                                            <input type="number" class="form-control" id="days" name="days" required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Сохранить</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card card-bordered h-100">
                            <div class="card-inner">
                                <form class="crutch-validate is-alter" action="<?php echo e(route('panel.products.actual', $product)); ?>" method="post">
                                    <div class="form-group">
                                        <div class="form-label">
                                            <span>Актуальное?</span>
                                        </div>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="actual" name="actual" <?php echo e($product->actual ? 'checked' : ''); ?>>
                                            <label class="custom-control-label" for="actual"></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary">Сохранить</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3">
                <div class="card card-bordered">
                    <div class="card-inner">
                        <form class="crutch-validate is-alter" action="<?php echo e(route('panel.products.update_attributes', $product)); ?>" method="post">
                            <?php $__currentLoopData = $product->category->allAttributes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group">
                                    <label class="form-label" for="attribute-<?php echo e($attribute->id); ?>"><?php echo e($attribute->name); ?></label>
                                    <div class="form-control-wrap">
                                        <?php if($attribute->isSelect()): ?>
                                            <select id="attribute-<?php echo e($attribute->id); ?>" class="form-control form-select select2-hidden-accessible" name="attributes[<?php echo e($attribute->id); ?>]" data-placeholder="Выбрать вариант" data-msg="Выберите <?php echo e($attribute->name); ?>" <?php echo e($attribute->required ? 'required' : ''); ?>>
                                                <option label="empty" value=""></option>
                                                <?php $__currentLoopData = $attribute->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($variant); ?>" <?php echo e($variant === $product->getValue($attribute->id) ? 'selected': ''); ?>><?php echo e($variant); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        <?php else: ?>
                                            <input type="<?php echo e($attribute->isNumber() ? 'number': 'text'); ?>" class="form-control" id="attribute-<?php echo e($attribute->id); ?>" name="attributes[<?php echo e($attribute->id); ?>]" value="<?php echo e($product->getValue($attribute->id)); ?>" <?php echo e($attribute->required ? 'required' : ''); ?>>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="form-group">
                                <button type="submit" class="btn btn-lg btn-primary">Сохранить атрибуты</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="/dashboard/js/summernote.js"></script>
    <script src="/dashboard/js/editors.js"></script>
    <script src="/dashboard/js/slug.js"></script>

    <script>
      $(function () {
        const img = $('#img');

        const options = {
          url: '<?php echo e(route('services.upload.base')); ?>',
          maxFiles: 1,
          thumbnailWidth: 150,
          thumbnailHeight: 150,
          init: function () {
            this.on('maxfilesexceeded', function (file) {
              this.removeAllFiles();
              this.addFile(file);
            });
            this.on('success', function (file, res) {
              img.val(res.path || '').removeClass('invalid').nextAll('.invalid').hide();
              $('#product-img').remove();
            });
            this.on('removedfile', function () {
              img.val('');
            });
          },
        };
        $('.crutch-dropzone').crutchZone(options);

        $('.form-select').on('select2:select', function () {
          $(this).removeClass('invalid').nextAll('#category_id-error').hide();
        });

        $('#slug-generate').slugGenerate();
      });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.panel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/panel/products/edit.blade.php ENDPATH**/ ?>