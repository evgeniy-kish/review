<?php
/**
 * @var \App\Models\Rubric[]  $rubrics
 * @var \App\Models\Article[] $articles
 * @var \App\Models\Article[] $news
 */
?>



<?php $__env->startSection('title', 'Блог iRate'); ?>
<?php $__env->startSection('description', 'Читайте актуальные, интересные и подробные статьи и новости в блоге iRate.'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Breadcrumb Area-->
    <div class="breadcrumb--area bg-img bg-overlay jarallax" style="background-image: url('/img/custom-img/blog.jpg');">
        <div class="container h-100">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="breadcrumb-content">
                        <h2 class="breadcrumb-title"><?php echo e(__('Blog')); ?></h2>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="/"><?php echo e(__('Home')); ?></a></li>
                                <li class="breadcrumb-item active" aria-current="page"><a href="#"><?php echo e(__('Blog')); ?></a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Blog Area-->
    <div class="saasbox--blog--area section-padding-120">
        <div class="container">
            <div class="row justify-content-between">

                <div class="col-12 col-md-7" id="search-blog">
                    <?php echo $__env->make('blog.rows', compact('articles'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo e($articles->onEachSide(0)->links('partials.paginate')); ?>

                </div>

                <div class="col-12 col-md-5 col-lg-4">
                    <div class="blog-sidebar-area">
                        <!-- Single Widget Area-->
                        <div class="single-widget-area mb-5">
                            <!-- Search Form-->
                            <div class="widget-form">

                                <input
                                        class="form-control panel-search"
                                        data-search-target="#search-blog"
                                        data-search-url="<?php echo e(route('services.search.blog')); ?>"
                                        type="search"
                                        placeholder="<?php echo e(__('Blog search...')); ?>"
                                >

                                <button type="button"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                        <!-- Single Widget Area-->
                        <div class="single-widget-area mb-5">
                            <h4 class="widget-title mb-30"><?php echo e(__('Categories')); ?></h4>
                            <ul class="catagories-list pl-0">
                                <?php $__currentLoopData = $rubrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('blog.rubric', $rubric)); ?>">
                                            <i class="fa fa-angle-double-right" aria-hidden="true"></i><?php echo e($rubric->title); ?>

                                            <span class="text-muted ml-2">(<?php echo e($rubric->articles_count); ?>)</span>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Single Widget Area-->
                        <div class="single-widget-area mb-5">
                            <h4 class="widget-title mb-30"><?php echo e(__('New posts')); ?></h4>
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Single Recent Post-->
                            <div class="single-recent-post d-flex align-items-center">
                                <div class="post-thumb">
                                    <a href="<?php echo e(route('blog.show', ['rubric_slug' => $article->rubric->slug, 'article' => $article->slug])); ?>">
                                        <img src="<?php echo e($article->img); ?>" alt="<?php echo e($article->title); ?>">
                                    </a>
                                </div>
                                <div class="post-content">
                                    <a class="post-title" href="<?php echo e(route('blog.show', ['rubric_slug' => $article->rubric->slug, 'article' => $article->slug])); ?>"><?php echo e($article->title); ?></a>
                                    <p class="post-date"><?php echo e($article->created_at->format('d.m.Y')); ?></p>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- Single Widget Area-->




















                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Cool Facts Area-->
    <section class="cta-area cta3 py-5">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-sm-8">
                    <div class="cta-text mb-4 mb-sm-0">
                        <h3 class="text-white mb-0"><?php echo e(__('Interesting product')); ?></h3>
                    </div>
                </div>
                <div class="col-12 col-sm-4 text-sm-right"><a class="btn saasbox-btn white-btn" href="#"><?php echo e(__('Go')); ?></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="/js/panel/search.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/irate.info/data/www/irate.info/resources/views/blog/index.blade.php ENDPATH**/ ?>