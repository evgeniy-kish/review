<?php $__env->startSection('title', __('Registration')); ?>
<?php $__env->startSection('description', __('Registration')); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-block nk-block-middle nk-auth-body">
        <div class="brand-logo pb-5">
            <a href="<?php echo e(route('home')); ?>" class="logo-link">
                <img class="logo-light logo-img logo-img-lg" src="/img/core-img/logo-white.png" alt="logo">
                <img class="logo-dark logo-img logo-img-lg" src="/img/core-img/logo.png" alt="logo-dark">
            </a>
        </div>
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h5 class="nk-block-title"><?php echo e(__('Registration')); ?></h5>
                <div class="nk-block-des">
                    <p><?php echo e(__('Create a new account.')); ?></p>
                </div>
            </div>
        </div>

        <form action="<?php echo e(route('register.store')); ?>" class="crutch-validate is-alter" method="post">
            <div class="form-group">
                <label class="form-label" for="name"><?php echo e(__('Name')); ?></label>
                <div class="form-control-wrap">
                    <input type="text" class="form-control form-control-lg" id="name" name="name"
                            placeholder="<?php echo e(__('Your name')); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <div class="form-control-wrap">
                    <input type="email" class="form-control form-control-lg" id="email" name="email"
                            placeholder="<?php echo e(__('Your email')); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label" for="password"><?php echo e(__('Password')); ?></label>
                <div class="form-control-wrap">
                    <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch lg" data-target="password">
                        <em class="passcode-icon icon-show icon ni ni-eye"></em>
                        <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                    </a>
                    <input type="password" class="form-control form-control-lg" id="password" name="password"
                            placeholder="<?php echo e(__('Your password')); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label" for="password_confirmation"><?php echo e(__('Password confirmation')); ?></label>
                <div class="form-control-wrap">
                    <a tabindex="-1" href="#" class="form-icon form-icon-right lg passcode-switch" data-target="password_confirmation">
                        <em class="passcode-icon icon-show icon ni ni-eye"></em>
                        <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                    </a>
                    <input type="password" class="form-control form-control-lg" id="password_confirmation"
                            name="password_confirmation" placeholder="<?php echo e(__('Password confirmation')); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <div class="custom-control custom-control-xs custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="tos" name="tos" required>
                    <label class="custom-control-label" for="tos">
                        <?php echo e(__('I agree with')); ?>

                        <a tabindex="-1" href="<?php echo e(route('terms-for-use')); ?>">
                            <?php echo e(__('user agreement')); ?>

                        </a>
                        <?php echo e(__('and')); ?>

                        <a tabindex="-1" href="<?php echo e(route('privacy-policy')); ?>">
                            <?php echo e(__('the privacy policy')); ?>

                        </a>
                        <?php echo e(config('app.name')); ?>.
                    </label>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-lg btn-primary btn-block"><?php echo e(__('Sign up')); ?></button>
            </div>
        </form>

        <div class="form-note-s2 pt-4">
            <?php echo e(__('Already have an account?')); ?>

            <a href="<?php echo e(route('login')); ?>"><strong><?php echo e(__('Login')); ?></strong></a>
        </div>
        <?php echo $__env->make('auth.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/irate.info/data/www/irate.info/resources/views/auth/register.blade.php ENDPATH**/ ?>