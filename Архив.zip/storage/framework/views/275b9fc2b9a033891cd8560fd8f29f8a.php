<?php $__env->startSection('title', __('Login')); ?>
<?php $__env->startSection('description', __('Login')); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-block nk-block-middle nk-auth-body">
        <div class="brand-logo pb-5">
            <a href="<?php echo e(route('home')); ?>" class="logo-link">
                <img class="logo-light logo-img logo-img-lg" src="/img/core-img/logo-white.png" alt="logo">
                <img class="logo-dark logo-img logo-img-lg" src="/img/core-img/logo.png" alt="logo-dark">
            </a>
        </div>
        <div class="nk-block-head">
            <div class="nk-block-head-content">
                <h5 class="nk-block-title"><?php echo e(__('Login')); ?></h5>
                <div class="nk-block-des">
                    <p><?php echo e(__('Use your username and password to login.')); ?></p>
                </div>
            </div>
        </div>
        <form action="<?php echo e(route('login.store')); ?>" class="crutch-validate is-alter" method="post">
            <div class="form-group">
                <label class="form-label" for="email">Email</label>
                <div class="form-control-wrap">
                    <input type="email" class="form-control form-control-lg" id="email" name="email"
                            placeholder="<?php echo e(__('Your email')); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <div class="form-label-group">
                    <label class="form-label" for="password"><?php echo e(__('Password')); ?></label>
                    <a class="link link-primary link-sm" tabindex="-1" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot your password?')); ?>

                    </a>
                </div>
                <div class="form-control-wrap">
                    <a tabindex="-1" href="#" class="form-icon form-icon-right passcode-switch lg" data-target="password">
                        <em class="passcode-icon icon-show icon ni ni-eye"></em>
                        <em class="passcode-icon icon-hide icon ni ni-eye-off"></em>
                    </a>
                    <input type="password" class="form-control form-control-lg" id="password" name="password"
                            placeholder="<?php echo e(__('Your password')); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-lg btn-primary btn-block"><?php echo e(__('Login')); ?></button>
            </div>
        </form>
        <div class="form-note-s2 pt-4">
            <?php echo e(__('First time with us?')); ?> <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Create an account')); ?></a>
        </div>
        <?php echo $__env->make('auth.social', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Мой Mac/programm/irate.local.info/resources/views/auth/login.blade.php ENDPATH**/ ?>