(function ($, NioApp) {
  $.ajaxSetup({ headers: { 'X-Key': document.querySelector('meta[name="csrf-key"]').content } });
  NioApp.Passcode('.passcode-switch-s');

  var motor = {
    success: function (j,form) {
      var s = '<div class="nk-block-head"><div class="nk-block-head-content"><h5 class="nk-block-title">Thank you for submitting form</h5><div class="nk-block-des text-success"><p>Check Your email</p></div></div></div>';
      form.parent().html(s);
      Swal.fire({ title: 'Thank you for submitting form', text: 'Check Your email', icon: 'success' })
    },
    redirect: function (j) {
      location.assign(j['to'] || '/');
    }
  };

  // noinspection ES6ConvertVarToLetConst
  var validators = [];

  $('.form-validate-s').each(function (i,el) {
    validators[i] = $(el).validate({
      errorElement: 'span',
      errorClass: 'invalid',
      errorPlacement: function errorPlacement (error, element) {
        error.appendTo(element.parent());
      },
      submitHandler: function (form) {
        // noinspection ES6ConvertVarToLetConst
        var _form = $(form);
        _form
          .find('button')
          .attr('disabled', 'disabled')
          .find('span')
          .toggleClass('d-none');

        $.post(_form.attr('action'), _form.serialize(), null, 'json').done(function (json) {
          if ('action' in json && json['action'] in motor) {
            return motor[json['action']](json, _form);
          }

          return alert('Forbidden!');
        }).fail(function (j) {
          if (j.status !== 422 || !('errors' in j.responseJSON)) {
            return alert('Forbidden!');
          }

          return validators[i].showErrors(j.responseJSON['errors']);
        }).always(function () {
          _form.find('button')
            .removeAttr('disabled')
            .find('span')
            .toggleClass('d-none');
        });
      }
    });
  });
})(jQuery, NioApp, Swal);
