if (typeof jQuery !== 'undefined' && jQuery !== null) {
  jQuery.fn.slugGenerate = function (options) {
    const settings = {
      title: 'title',
      slug: 'slug'
    };

    return this.each(function () {
      if (options) {
        $.extend(settings, options);
      }
      const title = $('#' + settings.title);
      const slug = $('#' + settings.slug);
      const generate = $(this);

      generate.on('click', function (e) {
        e.preventDefault();
        const title_text = title.val();

        if ('' !== title_text.trim()) {
          generate.attr('disabled', 'disabled');

          $.post('/api/services/slugify', { slug: title_text }, null, 'json')
            .done(function (res) {
              if (!('slug' in res)) {
                return alert('Forbidden!');
              }
              slug.val(res.slug);
              slug.removeClass('invalid').addClass('valid').nextAll('span').hide();
            })
            .fail(function (r) {})
            .always(function () { generate.removeAttr('disabled'); });
        }
      });

    });
  };
}
