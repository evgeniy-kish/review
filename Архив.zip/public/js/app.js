(function () {
  $('.like-touch').on('click', function (e) {
    e.preventDefault();
    const _a = $(this);
    const _v = +!_a.hasClass('liked');
    const _t = +_a.next().text() + (_v ? 1 : -1);

    _a.toggleClass('liked').next().text(_t > 0 ? _t : '');

    $.ajax({
      headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content },
      url: _a.data('action'),
      method: 'POST',
      data: { act: _t },
    });
  });
})();
