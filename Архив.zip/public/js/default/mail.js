// noinspection ES6ConvertVarToLetConst

$(function () {
  // Get the form.
  var form = $('#main_contact_form');
  // Get the messages div.
  var formMessages = $('#success_fail_info');
  // Set up an event listener for the contact form.
  form.on('submit', function (e) {
    // Stop the browser from submitting the form.
    e.preventDefault();

    // Serialize the form data.
    var formData = form.serialize();

    // Submit the form using AJAX.
    $.ajax({
      type: 'POST',
      url: form.attr('action'),
      data: formData
    })
      .done(function (response) {
        // Make sure that the formMessages div has the 'success' class.
        formMessages
          .removeClass('alert alert-danger')
          .addClass('alert alert-primary')
          .text('Спасибо! Почта отправлена');

        form.trigger('reset');
      })
      .fail(function (data) {
        // Make sure that the formMessages div has the 'error' class.
        formMessages
          .removeClass('alert alert-primary')
          .addClass('alert alert-danger');

        // Set the message text.
        if (data.responseText !== '') {
          formMessages.text(data.responseText);
        } else {
          formMessages.text('Oops! An error occured.');
        }
      });
  });
});
